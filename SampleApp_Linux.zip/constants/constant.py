line = 90
encodingtype = 'utf-8'
errorCode1 = 400
maxRevCount = 600
revPageCount = 20